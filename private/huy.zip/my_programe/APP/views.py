from django.shortcuts import render
from django.http import HttpResponse
import random

# Create your views here.
def index(request):
    return HttpResponse('Это моя первая страница на Django!')


    
def game_view(request):
    num1 = random.randint(0, 9)
    num2 = random.randint(0, 9)
    num3 = random.randint(0, 9)



    if num1 == num2 == num3:
        return HttpResponse(f'Победа, все 3 числа равны: {num1} {num2} {num3}')
    elif num1 == num2 != num3 or num2 == num3 != num1 or num3 == num1 != num2:
        return HttpResponse(f'Ура! Два числа равны: {num1} {num2} {num3}')
    else:
        return HttpResponse('Повезет в следующий раз!')